﻿INSTALL:
	1. Place resource in "resources" folder of server
	2. Run server. add python script to meta.xml "pythonstart" 